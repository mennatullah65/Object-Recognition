function [ ] = APPLAY( mat,n )
%UNTITLED13 Summary of this function goes here
%   Detailed explanation goes here
sre=SRE(mat)
lre=LRE(mat)
GLD=GLNU(mat)
RLD=RLNU(mat)
rp=RP(mat,n)
lgre=LGRE(mat)
hgre=HGRE(mat)
srlge=SRLGE(mat)
srhge=SRHGE(mat)
lrhge=LRHGE(mat)
lrlge=LRLGE(mat)

end

