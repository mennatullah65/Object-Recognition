function [ rp ] = RP( mat ,n)
%UNTITLED12 Summary of this function goes here
%   Detailed explanation goes here
rp=sum(sum(mat))/n;
end

